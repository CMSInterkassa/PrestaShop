<?php
//Модуль разработан в компании GateOn предназначен для CMS Prestashop 1.6
//Сайт разработчикa: www.gateon.net
//E-mail: www@smartbyte.pro
//Версия: 1.1


class Interkassa extends PaymentModule
{
	private	$_html = '';
	private $_postErrors = array();

	public function __construct()
	{
		$this->name = 'interkassa';
		$this->tab = 'payments_gateways';
		$this->version = '1.1';
		
		$this->currencies = true;
		$this->currencies_mode = 'checkbox';
		
		$config = Configuration::getMultiple(array('ik_shop_id','secret_key', 'test_key', 'api_mode', 'api_id', 'api_key'));
		if (isset($config['ik_shop_id']))
			$this->purse_r = $config['ik_shop_id'];
		if (isset($config['secret_key']))
			$this->ikey = $config['secret_key'];
		if(isset($config['test_key'])){
			$this->t_key = $config['test_key'];
		}
		if(isset($config['api_mode'])){
			$this->api_mode = $config['api_mode'];
		}
		if(isset($config['api_id'])){
			$this->api_id = $config['api_id'];
		}
		if(isset($config['api_key'])){
			$this->api_key = $config['api_key'];
		}
		parent::__construct();

		$this->displayName = $this->l('Interkassa');
		$this->description = $this->l('Accepts payments by Interkassa');
		$this->confirmUninstall = $this->l('Are you sure you want to delete your details ?');
		if (!isset($this->purse_r))
			$this->warning = $this->l('Add any purse');
		if (!isset($this->ikey))
			$this->warning = $this->l('Add secret key');
		
	}

	public function install()
	{
		if (!parent::install()
            OR !$this->registerHook('payment')
            OR !$this->registerHook('paymentReturn')
           
           )
			return false;
		return true;
	}

	public function uninstall()
	{
		if (!Configuration::deleteByName('ik_shop_id')
			OR !Configuration::deleteByName('ik_shop_id')
			OR !Configuration::deleteByName('secret_key')
			OR !Configuration::deleteByName('test_key')
			OR !Configuration::deleteByName('api_mode')
			OR !Configuration::deleteByName('api_id')
			OR !Configuration::deleteByName('test_key')
			OR !parent::uninstall())
			return false;
		return true;
	}


	private function _postValidation()
	{
		if (isset($_POST['submitInterkassa']))
		{
			if (empty($_POST['purse_r']))
				$this->_postErrors[] = $this->l('Add any purse');
			if (empty($_POST['ikey']))
				$this->_postErrors[] = $this->l('Add secret key');
		}
	}
	
	private function _postProcess()
	{
		if (isset($_POST['submitInterkassa']))
		{
			Configuration::updateValue('ik_shop_id', $_POST['purse_r']);
			Configuration::updateValue('secret_key', $_POST['ikey']);
			Configuration::updateValue('test_key', $_POST['t_key']);
            Configuration::updateValue('ik_test_mode', $_POST['ik_test_mode']);
            Configuration::updateValue('api_mode', $_POST['api_mode']);
            Configuration::updateValue('api_id', $_POST['api_id']);
            Configuration::updateValue('api_key', $_POST['api_key']);
		}
		$this->_html .= '<div class="conf confirm"><img src="../img/admin/ok.gif" alt="'.$this->l('ok').'" /> '.$this->l('Settings updated').'</div>';
	}
	
	private function _displayInterkassa()
	{
		$this->_html .= '
		<img src="../modules/interkassa/logo_settings.png" style="float:left; margin-right:15px;" />
		<b>'.$this->l('This module allows you to accept payments by Interkassa.').'</b><br /><br />
		<br /><br />';
	}
	
	private function _displayForm()
	{
         if ($ik_test_mode = Tools::getValue('ik_test_mode')) Configuration::updateValue('INTERKASSA2_TEST_MODE', $ik_test_mode);
        $this->_html .='
     <form action="' . $_SERVER['REQUEST_URI'] . '" method="post">
          <fieldset>
          <legend><img width="20px" src="' . __PS_BASE_URI__ . 'modules/interkassa2/logo.gif" />' . $this->l('Settings') . '</legend>
            <p>' . $this->l('Use the test mode to go directly to the test payment system, without the possibility of choice of other payment systems') . '
            </p>
            <label>
              ' . $this->l('Mode') . '
            </label>
            <div class="margin-form" style="width:110px;">
              <select name="ik_test_mode">
                <option value="live"' . (Configuration::get('INTERKASSA2_TEST_MODE') == 'live' ? ' selected="selected"' : '') . '>' . $this->l('Work mode')
            . '&nbsp;&nbsp;
                </option>
                <option value="test"' . (Configuration::get('INTERKASSA2_TEST_MODE') == 'test' ? ' selected="selected"' : '') . '>' . $this->l('Test mode')
            . '&nbsp;
                &nbsp;
                </option>
              </select>
            </div>
            <div><label>' . $this->l('ik_shop_id:') . '</label>
                <div class="margin-form"><input type="text" size="33" maxlength="36" name="purse_r" value="' . htmlentities(Tools::getValue('purse_r', $this->purse_r), ENT_COMPAT, 'UTF-8') . '" />
                    <p>'.$this->l('No more than').'</p></div>
                    <div><label>' . $this->l('secret_key:') . '</label>
                        <div class="margin-form"><input type="text" size="33" maxlength="30" name="ikey" value="' . htmlentities(Tools::getValue
            ('ikey', $this->ikey), ENT_COMPAT, 'UTF-8') . '" />
                            <p>'.$this->l('No more than').'</p>
                        </div><label>' . $this->l('test_key:') . '</label>
                        <div class="margin-form"><input type="text" size="33" maxlength="30" name="t_key" value="' . htmlentities(Tools::getValue('t_key', $this->t_key), ENT_COMPAT, 'UTF-8') . '" />
                            <p>'.$this->l('No more than').'</p></div>
                    <div class="margin-form">       
                <h2><strong>' . $this->l('Use new Interkassa API'). '</strong></h2>
               <h3>' . $this->l('API settings locate in your Interkassa account settings in API section'). '</h3>
               <h3>' . $this->l('To use Interkassa API select API mode. On the payment methods selection page you will see button') . '
            </h3>
            </div>
            <label>
              ' . $this->l('API mode') . '
            </label>
            <div class="margin-form">
              <select name="api_mode">
                <option value="no_selected"'.(htmlentities(Tools::getValue('api_mode', $this->api_mode)) == 'no_selected' ? ' selected="selected"' : '') .
            '>' . $this->l('no_selected_api_mode') .'</option>
                <option value="on"' . (htmlentities(Tools::getValue('api_mode', $this->api_mode)) == 'on' ? ' selected="selected"' : '') . '>' . $this->l('ON')
            . '</option>
                <option value="off"' . (htmlentities(Tools::getValue('api_mode', $this->api_mode)) == 'off' ? ' selected="selected"' : '') . '>' . $this->l('OFF')
            . '</option>
              </select>
            </div>
              <label>
              ' . $this->l('Interkassa API Id') . '
            </label>
            <div class="margin-form">
              <input type="text"' . (htmlentities(Tools::getValue('api_id', $this->api_id)) == 'on' ? ' required="required"' : '') . '  name="api_id" value="' . htmlentities(Tools::getValue('api_id', $this->api_id)). '"  />
            </div> 
            <label>
              ' . $this->l('Interkassa API Key') . '
            </label>
            <div class="margin-form">
              <input type="text"' . (htmlentities(Tools::getValue('api_key', $this->api_key)) == 'on' ? ' required="required"' : '') . '  name="api_key" value="' . htmlentities(Tools::getValue('api_key', $this->api_key)). '"  />
            </div> 
							<p>Введите тестовый ключ магазина максимум 30 символов </p>
							<br /><center><input type="submit" name="submitInterkassa" value="'.$this->l('Save').'" class="button" /></center>
						</fieldset>
					</form>
                    
                    
                    <br /><br />
					<fieldset class="width3">
						<legend><img src="../img/admin/warning.gif" />'.$this->l('Information').'</legend>
						<b style="color: red;">'.$this->l('What connect Interkassa:').'</b><br />
						Зайдите на сайт <b>http://interkassa.com/</b> и пройдите процедуру &quot;Регистрации&quot;.После авторизации заполните поля "Название магазина", URl магазина и нажмите "Добавить (+)". <br />
						<br />После добавления магазина нажмите "Настроить" и произведите настройки по примеру:</p>
						<ul>
							<li><b>URL Успешной оплаты:</b>http://yourrestashop.com/modules/interkassa/success.php Метод передачи Success URL "LINK"</li>
							<li><b>URL Неуспешной оплаты:</b>http://yourrestashop.com/modules/interkassa/fail.php Метод передачи Fail URL "LINK"</li>
							<li><b>URL Ожидания оплаты:</b>http://yourrestashop.com/modules/interkassa/fail.php Метод передачи Fail URL "LINK"</li>
							<li><b>URL Взаимодействия:</b>http://yourrestashop.com/modules/interkassa/validation.php Метод передачи Status URL "POST"</li>
							<li>Также укажите в настройках вашей кассы в разделе Безопасность проверять ли цифровую подпись, это существенно поможет улучшить безопасность</li>
							<li><b style="color: red;">!!! Если Валюта отлична от USD то необхедимо указать "Курс валюты"</b></li>

						</ul>			
					</fieldset>
				</form>';
			}


			public function getContent()
			{
				$this->_html = '<h2>'.$this->displayName.'</h2>';

				if (!empty($_POST))
				{
					$this->_postValidation();
					if (!sizeof($this->_postErrors))
						$this->_postProcess();
					else
						foreach ($this->_postErrors AS $err)
							$this->_html .= '<div class="alert error">'. $err .'</div>';
					}
					else
						$this->_html .= '<br />';

					$this->_displayInterkassa();
					$this->_displayForm();

					return $this->_html;
				}




				public function hookPayment($params)
				{
					if (!$this->active)
						return ;

					global $smarty;

					$id_currency = intval($params['cart']->id_currency);
					$currency = new Currency(intval($id_currency));

					if ($currency->iso_code == 'RUB' && Configuration::get('ik_shop_id'))
						{$purse = Configuration::get('ik_shop_id');}
					else
						{$purse = Configuration::get('ik_shop_id'); 
				// $currency = $this->getCurrency();
				}
				


				$ik_shop_id = $purse;
				
				$ik_payment_amount = number_format(Tools::convertPrice($params['cart']->getOrderTotal(true, 3), $currency), 2, '.', '');
				$ik_payment_id = intval($params['cart']->id);

				$ik_payment_desc = 'Оплата заказа №'.$ik_payment_id;
				$ik_paysystem_alias = '';
				$ik_baggage_fields = '';

				$ik_sign_hash = '';
				$secret_key = Configuration::get('secret_key');


				$arg = [
				'ik_cur'=>$currency->iso_code,
				'ik_co_id'=>$purse,
				'ik_pm_no'=>intval($params['cart']->id),
				'ik_am'=>$ik_payment_amount,
				'ik_desc'=>'#'.intval($params['cart']->id)
				];
				ksort($arg,SORT_STRING);
				array_push($arg, $secret_key );
				$arg = implode(':', $arg);
				$signature = base64_encode(md5($arg, true));


				$smarty->assign(array(
					'purse' => $purse,
					'currency' => $currency->iso_code,
					'total' => $ik_payment_amount,
					'id_cart' => intval($params['cart']->id),
					'returnUrl' => 'http://'.htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8').__PS_BASE_URI__.'modules/interkassa/validation.php',
					'cancelUrl' => 'http://'.htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8').__PS_BASE_URI__.'order.php',
					'this_path' => $this->_path,
					'sign_hash' => $signature
					));
					
				$api_id = Configuration::get('api_id');
                $api_key = Configuration::get('api_key');
                $parameters['payment_systems'] = $this->getIkPaymentSystems($ik_shop_id, $api_id, $api_key);
                $parameters['payment_systems_path'] = $this->_path . 'paysystems/';
                $parameters['img_path'] = $this->_path;
                //$parameters['ajax_url'] = Tools::getHttpHost(true) . __PS_BASE_URI__ . 'modules/interkassa/ajax.php';
                $parameters['ajax_url'] = '/modules/interkassa/ajax.php';
                $parameters['api_mode'] = Configuration::get('api_mode');
                $api_mode = Configuration::get('api_mode');

                $smarty->assign($parameters);
                
               	$test= $this->getIkPaymentSystems($ik_shop_id, $api_id, $api_key);
        $str_a = '';
            if($api_mode === 'on'){
                $str_a = "<a class='bankwire' title='Оплатить через Интеркассу' style='line-height: 100%; ' data-toggle='modal' data-target='#InterkassaModal'>";
            }
            else{
                $str_a = "<a class='bankwire' href='javascript:$(".'"'."#interkassa".'"'.").submit();' title='Оплатить через Интеркассу' style='line-height: 100%;'>";
            }
		$str = '';
		foreach ($test as $ps => $info){
			$str .="
			<script href='modules/interkassa/assets/ik.js'></script>
			<div class='col-md-3 text-center payment_system'>
						<div class='panel panel-pricing'>
							<div class='panel-heading'>
								<img src='/modules/interkassa/paysystems/{$ps}.png' alt='{$info['title']}'>
								<h3 class='ps-title'>{$info['title']}</h3>
							</div>
							<div class='form-group'>
								<div class='input-group'>
									<div id='radioBtn'>";
										foreach ($info['currency'] as $currency => $currencyAlias){
									    	$str .= "<a class='btn btn-primary btn-sm notActive' data-toggle='fun'
										   data-title='{$currencyAlias}'>{$currency}</a>
										";}
										$str .= "</div>
									<input type='hidden' name='fun' id='fun'>
								</div>
							</div>
							<div class='panel-footer'>
								<a class='btn btn-lg btn-block btn-success ik-payment-confirmation' data-title='{$ps}' href='#'>Pay
									<br>
									<strong>{$info['title']}</strong>
								</a>
							</div>
						</div>
					</div>";}
				$str_modal = '';
            if($api_mode){
                $str_modal = "<div id='InterkassaModal' class='modal fade' role='dialog'>
                            	<div class='modal-dialog modal-lg'>
                            		<div class='modal-content' id='plans'>
                            			<div class='container'>
                            				<div class='row'>
                                                <h1>
                            						1.Choose your preferred payment system<br>
                            						2.Specify the currency among available<br>
                            						3.Click Pay
                            					</h1>
                                                {$str}
                            				</div>
                            			</div>
                            		</div>
                            	</div>
                            </div>";
            }

				//return $this->display(__FILE__, 'interkassa.tpl');
				return $html="
				    <div class='row'>
	<div class='col-xs-12'>
		<p class='payment_module'>
			{$str_a}


				<img src='/modules/interkassa/interkassa.gif' style='float:left; height: 100%' title='Интеркасса' alt='Интеркасса'/>
				<br style='clear:both;' />
			</a>
		</p>
		<form id='interkassa' accept-charset='utf-8' method='POST' action='https://sci.interkassa.com'>
			<input type='hidden' name='ik_am' value='{$ik_payment_amount}'>
			<input type='hidden' name='ik_cur' value='{$currency->iso_code}'>
			<input type='hidden' name='ik_desc' value='{$ik_payment_desc}'>
			<input type='hidden' name='ik_pm_no' value='{$ik_payment_id}'>
			<input type='hidden' name='ik_co_id' value='{$ik_shop_id}'>
			<input type='hidden' name='ik_sign' value='{$signature}'>
		</form>
	</div>
</div>


{$str_modal}

<script type='text/javascript'>

	var curtrigger = false;

	$('.ik-payment-confirmation').click(function () {
		$('#interkassa').submit();

	});

	$('#radioBtn a').click(function () {
		curtrigger = true;
		var ik_cur = this.innerText;
		var ik_pw_via = $(this).attr('data-title');
		var form = $('#interkassa');


		if($('input[name =  ".'"ik_pw_via"'."]').length > 0){
			$('input[name =  ".'"ik_pw_via"'."]').val(ik_pw_via);
		}else{
			form.append(
					$('<input>', {
						type: 'hidden',
						name: 'ik_pw_via',
						val: ik_pw_via
					}));
		}
		$.post('{$ajax_url}',form.serialize() )
				.done(function (data) {
					console.log(data);
					if($('input[name =  ".'"ik_sign"'."]').length > 0){
						$('input[name =  ".'"ik_sign"'."]').val(data);
					}
				})
				.fail(function () {
					alert('Что-то не так. Выберите валюту еще раз');
				});
	});

	$('#radioBtn a').on('click', function () {
		var sel = $(this).data('title');
		var tog = $(this).data('toggle');
		$('#' + tog).prop('value', sel);
		$('a[data-toggle=".'"'."' + tog + '".'"'."]').not('[data-title=".'"'."' + sel + '".'"'."]').removeClass('active').addClass('notActive');
		$('a[data-toggle=".'"'."' + tog + '".'"'."][data-title=".'"'."' + sel + '".'"'."]').removeClass('notActive').addClass('active');
	})

</script>


<style>
    #InterkassaModal{
        z-index: 100000;
    }
	#InterkassaModal .input-group,#InterkassaModal h1{
		text-align: center;
	}

	.payment_system h3, .payment_system img {
		display: inline-block;
		width: 100%;
	}

	.payment_system .panel-heading {
		text-align: center;
	}

	.payment_system .btn-primary, .payment_system .btn-secondary, .payment_system .btn-tertiary {
		padding: 6px;
	}
	.ps-title{
		font-size: 18px;
	}
	.panel-pricing {
		-moz-transition: all .3s ease;
		-o-transition: all .3s ease;
		-webkit-transition: all .3s ease;
	}

	.panel-pricing:hover {
		box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.2);
	}

	.panel-pricing .panel-heading {
		padding: 20px 10px;
	}

	.panel-pricing .panel-heading .fa {
		margin-top: 10px;
		font-size: 58px;
	}

	.panel-pricing .list-group-item {
		color: #777777;
		border-bottom: 1px solid rgba(250, 250, 250, 0.5);
	}

	.panel-pricing .list-group-item:last-child {
		border-bottom-right-radius: 0px;
		border-bottom-left-radius: 0px;
	}

	.panel-pricing .list-group-item:first-child {
		border-top-right-radius: 0px;
		border-top-left-radius: 0px;
	}

	.panel-pricing .panel-body {
		background-color: #f0f0f0;
		font-size: 40px;
		color: #777777;
		padding: 20px;
		margin: 0px;
	}

	#radioBtn .notActive {
		color: #3276b1;
		background-color: #fff;
	}

	.modal {
		display: none;
		overflow: hidden;
		position: fixed;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		z-index: 1050;
		-webkit-overflow-scrolling: touch;
		outline: 0;
	}
	.modal.fade .modal-dialog {
		-webkit-transform: translate(0, -25%);
		-ms-transform: translate(0, -25%);
		-o-transform: translate(0, -25%);
		transform: translate(0, -25%);
		-webkit-transition: -webkit-transform 0.3s ease-out;
		-o-transition: -o-transform 0.3s ease-out;
		transition: transform 0.3s ease-out;
	}
	.modal.in .modal-dialog {
		-webkit-transform: translate(0, 0);
		-ms-transform: translate(0, 0);
		-o-transform: translate(0, 0);
		transform: translate(0, 0);
	}
	.modal-open .modal {
		overflow-x: hidden;
		overflow-y: auto;
	}
	.modal-dialog {
		padding: 15px;
		position: relative;
		width: auto;
		margin: 10px;
	}
	.modal-content {
		position: relative;
		background-color: #ffffff;
		border: 1px solid #999999;
		border: 1px solid rgba(0, 0, 0, 0.2);
		border-radius: 6px;
		-webkit-box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
		box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
		-webkit-background-clip: padding-box;
		background-clip: padding-box;
		outline: 0;
		padding: 15px;
	}
	.modal-header .close {
		margin-top: -2px;
	}
	.modal-footer .btn + .btn {
		margin-left: 5px;
		margin-bottom: 0;
	}
	.modal-footer .btn-group .btn + .btn {
		margin-left: -1px;
	}
	.modal-footer .btn-block + .btn-block {
		margin-left: 0;
	}
	@media (min-width: 768px) {
		.modal-dialog {
			width: 600px;
			margin: 30px auto;
		}
		.modal-content {
			-webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
			box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
		}
	}
	@media (min-width: 992px) {
		.modal-lg {
			width: 900px;
		}
	}
</style>


				";
			}
			
			  public function getIkPaymentSystems($ik_co_id, $ik_api_id,$ik_api_key){
        $username = $ik_api_id;
        $password = $ik_api_key;
        $remote_url = 'https://api.interkassa.com/v1/paysystem-input-payway?checkoutId='.$ik_co_id;
        
        $businessAcc = $this->getIkBusinessAcc($username, $password);
   
            
        $ikHeaders = [];
        $ikHeaders[] = "Authorization: Basic " . base64_encode("$username:$password");
        if (!empty($businessAcc)) {
            $ikHeaders[] = "Ik-Api-Account-Id: " . $businessAcc;
        }
                
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $remote_url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $ikHeaders);
        $response = curl_exec($ch);
        $json_data = json_decode($response);
        
        if (empty($json_data))
            echo'<strong style="color:red;">Error!!! System response empty!</strong>';

            if ($json_data->status != 'error') {
                $payment_systems = array();
                if (!empty($json_data->data)) {
                    
                    foreach ($json_data->data as $ps => $info) {
                        $payment_system = $info->ser;
                        if (!array_key_exists($payment_system, $payment_systems)) {
                            $payment_systems[$payment_system] = array();
                            foreach ($info->name as $name) {
                                if ($name->l == 'en') {
                                    $payment_systems[$payment_system]['title'] = ucfirst($name->v);
                                }
                                $payment_systems[$payment_system]['name'][$name->l] = $name->v;
                            }
                        }
                        $payment_systems[$payment_system]['currency'][strtoupper($info->curAls)] = $info->als;
                    }
                }
                    
                return !empty($payment_systems) ? $payment_systems : '<strong style="color:red;">API connection error or system response empty!</strong>';
            } else {
                if (!empty($json_data->message))
                    echo '<strong style="color:red;">API connection error!<br>' . $json_data->message . '</strong>';
                else
                    echo '<strong style="color:red;">API connection error or system response empty!</strong>';
            }
        }
        
    public function getIkBusinessAcc($username = '', $password = '')         {
            $tmpLocationFile = __DIR__ . '/tmpLocalStorageBusinessAcc.ini';
            $dataBusinessAcc = function_exists('file_get_contents') ? file_get_contents($tmpLocationFile) : '{}';
            $dataBusinessAcc = json_decode($dataBusinessAcc, 1);
            $businessAcc = is_string($dataBusinessAcc['businessAcc']) ? trim($dataBusinessAcc['businessAcc']) : '';
            if (empty($businessAcc) || sha1($username . $password) !== $dataBusinessAcc['hash']) {
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL, 'https://api.interkassa.com/v1/' . 'account');
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
                curl_setopt($curl, CURLOPT_HEADER, false);
                curl_setopt($curl, CURLOPT_HTTPHEADER, ["Authorization: Basic " . base64_encode("$username:$password")]);
                $response = curl_exec($curl);
                $response = json_decode($response,1);


                if (!empty($response['data'])) {
                    foreach ($response['data'] as $id => $data) {
                        if ($data['tp'] == 'b') {
                            $businessAcc = $id;
                            break;
                        }
                    }
                }

                if (function_exists('file_put_contents')) {
                    $updData = [
                        'businessAcc' => $businessAcc,
                        'hash' => sha1($username . $password)
                    ];
                    file_put_contents($tmpLocationFile, json_encode($updData, JSON_PRETTY_PRINT));
                }

                return $businessAcc;
            }

            return $businessAcc;
    }
    
     public static function IkSignFormation($data){

        if (!empty($data['ik_sign'])) unset($data['ik_sign']);

        ksort($data, SORT_STRING);
        array_push($data, Configuration::get('secret_key'));
        $arg = implode(':', $data);
        $ik_sign = base64_encode(md5($arg, true));
        json_decode($ik_sign);

        return $ik_sign;
    }
 
		}
		
		

										
		
		?>
