<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{interkassa}prestashop>interkassa_bd01e8ed7165df62a994e526a24500c2'] = 'Интеркасса';
$_MODULE['<{interkassa}prestashop>interkassa_8ba1fb55373cb107afbcb5757ff6bdb4'] = 'Принимайте платежи с помощью Интеркасса 2.0';
$_MODULE['<{interkassa}prestashop>interkassa_fa214007826415a21a8456e3e09f999d'] = 'Вы уверены что хотите удалить все настройки?';
$_MODULE['<{interkassa}prestashop>interkassa_540bf82c8fb0b7f1b8ddad62c5024f12'] = 'Добавьте идентификатор магазина (ik_shop_id):';
$_MODULE['<{interkassa}prestashop>interkassa_65cbdfb8a8ce29be26be3d8b1e2d10c8'] = 'Добавьте Ваш текущий секретный ключ (secret_key)';
$_MODULE['<{interkassa}prestashop>interkassa_444bcb3a3fcf8389296c49467f27e1d6'] = 'Ок';
$_MODULE['<{interkassa}prestashop>interkassa_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{interkassa}prestashop>interkassa_8907d59e96906599b34f311b4f6bf9d3'] = 'Этот модуль позволит принимать платежи с помощью Интеркаса';
$_MODULE['<{interkassa}prestashop>interkassa_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{interkassa}prestashop>interkassa_791832642312c9e8c1255fab069f29bb'] = 'Идентификатор магазина (ik_shop_id):';
$_MODULE['<{interkassa}prestashop>interkassa_46036b2272fe91a3fdc1cd73fc42b0bb'] = 'Добавьте Ваш секретный ключ (secret_key):';
$_MODULE['<{interkassa}prestashop>interkassa_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{interkassa}prestashop>interkassa_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Информация';
$_MODULE['<{interkassa}prestashop>interkassa_8d5b7a447f8663fa0da571f69dbb545a'] = 'Как подключить Интеркассу:';

