<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{interkassa}prestashop>interkassa_info_fd22b2e8b83c14170b7e89917f9a3f74'] = 'Прием платежей с помощью кредитной карты быстро и безопасно с Интеркасса 2.0';
