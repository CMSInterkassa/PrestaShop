<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{interkassa}prestashop>interkassa_f785a41378aac9531e6472246cfa9207'] = 'Interkassa 2';
$_MODULE['<{interkassa}prestashop>interkassa_9b04bb0801c1f1f2b57acdb68278b81c'] = 'Pay with Interkassa';
$_MODULE['<{interkassa}prestashop>interkassa_159b2030df6273a9f2a9d4927b112325'] = 'Are you sure you want to remove?';
$_MODULE['<{interkassa}prestashop>interkassa_719a58231cab3ceeeb07fee120664773'] = 'Paid with Interkassa';
$_MODULE['<{interkassa}prestashop>interkassa_22199042a247bcf6ca710e07f8eaab7d'] = 'Insert Purse ID';
$_MODULE['<{interkassa}prestashop>interkassa_d10af29388f6cfe1ea1991e88e9aa39c'] = 'Insert secret key';
$_MODULE['<{interkassa}prestashop>interkassa_cb18a0821e6ccba6210611540662e3a2'] = 'Insert test key';
$_MODULE['<{interkassa}prestashop>interkassa_444bcb3a3fcf8389296c49467f27e1d6'] = 'OK';
$_MODULE['<{interkassa}prestashop>interkassa_9f4ee7194fe62f93faa7d64853cc6737'] = 'Module settings have been updated';
$_MODULE['<{interkassa}prestashop>interkassa_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{interkassa}prestashop>interkassa_791832642312c9e8c1255fab069f29bb'] = 'Purse ID';
$_MODULE['<{interkassa}prestashop>interkassa_68699d3177dcc8256bac5a0460f825bf'] = 'no more than 36 symbols';
$_MODULE['<{interkassa}prestashop>interkassa_46036b2272fe91a3fdc1cd73fc42b0bb'] = 'Secret Key';
$_MODULE['<{interkassa}prestashop>interkassa_467fb5bacea05971b0be77d91453bed5'] = 'Test Key';
$_MODULE['<{interkassa}prestashop>interkassa_c9cc8cce247e49bae79f15173ce97354'] = 'Save settings';
$_MODULE['<{interkassa}prestashop>interkassa_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Important information';
$_MODULE['<{interkassa}prestashop>interkassa_4eec452dee7d15acfb78a023b487bf19'] = 'Allow to override urls in your purse settings';
