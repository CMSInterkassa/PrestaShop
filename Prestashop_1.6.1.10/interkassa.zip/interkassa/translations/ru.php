<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{interkassa}prestashop>interkassa_f785a41378aac9531e6472246cfa9207'] = 'Интеркасса 2';
$_MODULE['<{interkassa}prestashop>interkassa_9b04bb0801c1f1f2b57acdb68278b81c'] = 'Позволяет проводить оплату с помощью Интеркассы';
$_MODULE['<{interkassa}prestashop>interkassa_159b2030df6273a9f2a9d4927b112325'] = 'Вы уверенны,что хотите удалить?';
$_MODULE['<{interkassa}prestashop>interkassa_719a58231cab3ceeeb07fee120664773'] = 'Оплачено с помощью Интеркассы';
$_MODULE['<{interkassa}prestashop>interkassa_22199042a247bcf6ca710e07f8eaab7d'] = 'Добавьте идентификатор кассы';
$_MODULE['<{interkassa}prestashop>interkassa_d10af29388f6cfe1ea1991e88e9aa39c'] = 'Добавьте секретный ключ';
$_MODULE['<{interkassa}prestashop>interkassa_cb18a0821e6ccba6210611540662e3a2'] = 'Добавьте тестовый ключ';
$_MODULE['<{interkassa}prestashop>interkassa_444bcb3a3fcf8389296c49467f27e1d6'] = 'Ок';
$_MODULE['<{interkassa}prestashop>interkassa_9f4ee7194fe62f93faa7d64853cc6737'] = 'Настройки были обновлены';
$_MODULE['<{interkassa}prestashop>interkassa_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{interkassa}prestashop>interkassa_791832642312c9e8c1255fab069f29bb'] = 'Добавьте Ваш идентификатор магазина (ik_co_id):';
$_MODULE['<{interkassa}prestashop>interkassa_68699d3177dcc8256bac5a0460f825bf'] = 'не больше 36 символов';
$_MODULE['<{interkassa}prestashop>interkassa_46036b2272fe91a3fdc1cd73fc42b0bb'] = 'Добавьте Ваш секретный ключ (secret_key):';
$_MODULE['<{interkassa}prestashop>interkassa_467fb5bacea05971b0be77d91453bed5'] = 'Добавьте Ваш тестовый ключ (secret_key):';
$_MODULE['<{interkassa}prestashop>interkassa_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить настройки';
$_MODULE['<{interkassa}prestashop>interkassa_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Информация';
$_MODULE['<{interkassa}prestashop>interkassa_4eec452dee7d15acfb78a023b487bf19'] = 'Разрешите переопределение URL в настройках вашей кассы';
