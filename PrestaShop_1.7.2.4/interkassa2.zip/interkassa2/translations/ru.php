<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{interkassa2}prestashop>interkassa2_info_fd22b2e8b83c14170b7e89917f9a3f74'] = 'Прием платежей с помощью кредитной карты быстро и безопасно с Интеркасса 2.0';
